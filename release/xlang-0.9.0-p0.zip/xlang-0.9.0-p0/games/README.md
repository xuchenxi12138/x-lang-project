# 示例程序

## 扫雷（图形界面）

```sh
cd games/minesweeper
../../bin/x.exe run minesweeper.xle --profile=desktop
```

**`--profile=desktop` 不能省。** 默认场景是 `console`，它不内嵌窗口
运行时，于是 `winOpen` 之类的调用不起作用，还会给一条警告：

```
warn: 程序用到了窗口能力，但场景 `console` 不内嵌窗口运行时
```

这不是错误，是场景选错了。三个场景的名字用 `x profile list` 查看。

也可以编成独立 exe：

```sh
../../bin/x.exe build minesweeper.xle -o minesweeper.exe --emit=exe \
    --profile=desktop --cc=<你的 gcc 路径>
```

`--cc` 需要一个能用的 gcc（mingw-w64）。**不装 gcc 也能玩** —— 用
`x run` 直接解释执行，不需要任何外部工具链。

## 界面样式演示

```sh
cd games/settings
../../bin/x.exe run demo.xle --profile=desktop
../../bin/x.exe run demo-class.xle --profile=desktop
```

这两份演示了形状原语、样式层与类封装的 UI 组件。

## 逻辑测试（无窗口）

```sh
cd games/minesweeper
../../bin/x.exe run board_test.xle
```

`board_test.xle` 只测棋盘逻辑，不开窗口也不要用 `--profile`，
适合在无图形环境（CI）里跑。
